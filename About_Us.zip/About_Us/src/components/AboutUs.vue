<template>
 <div class="app1">
    <div class="Color">
             <h1> About Us</h1>
        <div  class="img">
            
             <img src="../assets/img.jpg" /> 
                <p  >
                            TOTC is a platform that allows educators to create online classes whereby they can store the course materials online; manage assignments, quizzes and exams; monitor due dates; grade results and provide students with feedback all in one place.
                            TOTC is a platform that allows educators to create online classes whereby they can store the course materials online; manage assignments, quizzes and exams; monitor due dates; grade results and provide students with feedback all in one place. TOTC is a platform that allows educators to create online classes whereby they can store the course materials online; manage assignments, quizzes and exams; monitor due dates; grade results and provide students with feedback all in one place. TOTC is a platform
                            TOTC is a platform that allows educators to create online classes whereby they can store the course materials online; manage assignments, quizzes and exams; monitor due dates; grade results and provide students with feedback all in one place. TOTC is a platform that allows educators to create online classes whereby they can store the course materials online; manage

                </p>
           
        </div>
    </div>
      
  </div>
    
</template>

<script>
    export default{
        name: 'AboutUs'
    }
</script>

<style scoped>
.app1{
    margin-top: -60%;

}

img{
    width: 740px;
    height: 859px;
    flex-shrink: 0;
    text-align: center;
    margin-left: 20%;
    margin-top: 95px;
    display: inline-block;
    margin-left: 1px;
    margin-bottom: 157px;
    border-radius: 20px;
    
 
}
p{
    width: 700px;
    height: fit-content;
    color: #696984;
    font-family: Poppins;
    font-size: 24px;
    font-style: normal;
    font-weight: 400;
    line-height: 180%;
    letter-spacing: 0.48px;
    margin-left: 775px;
    margin-top: -901px;

}
p::first-letter {
  font-size: 2em; 
}

h1{
    text-align: center;
    color: black;
    text-align: center;
    font-family: serif;
    font-size: 44px;
    font-style: normal;
    font-weight: 600;
    line-height: 180%;
    letter-spacing: 5px;
    margin-top: 43px;
    margin-bottom: -161px;
    margin-left: 626px;
}
.Color{

}


</style>
