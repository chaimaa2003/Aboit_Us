<template>
  <div class="app">
      <!-- Navbar -->
      <Navbar />
      <div class="color"></div>
      <About />
  </div>
</template>

<script setup>
import Navbar from './components/Navbar.vue';
import About from './views/about.vue'
</script>

<style scoped>
.color {
  background-color: rgb(231, 242, 241);
  width: 100vw;
  height: 859px;
}
</style>
