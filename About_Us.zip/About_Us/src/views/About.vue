<template>
    <div class="Page">
     <div class="app">
        <AboutUs />
    </div>
    <div class="footer">
        <Footerr />
    </div>
    </div>
   
</template>

<script setup>
import AboutUs from '../components/aboutUs.vue';
import Footerr from '../components/Footer.vue';

</script>

<style scoped>
.Page {

}
</style>